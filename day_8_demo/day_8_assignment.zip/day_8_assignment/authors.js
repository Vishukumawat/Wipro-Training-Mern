db.Authors.insertMany([
  { name: "vishwas", nationality: "indian", birthYear: 2002 },
  { name: "jony", nationality: "america", birthYear: 2000 },
  { name: "don", nationality: "russia", birthYear: 1995 }
]);